import {expect, test} from "@playwright/test";

test("Search the Products in Amazon", async ({page}) =>
{
  await page.goto("https://www.amazon.in/");
  await page.getByPlaceholder("Search Amazon").fill("Yoga Mat");
  await page.getByPlaceholder("Search Amazon").press("Enter");
  await page.locator(".a-size-base-plus.a-spacing-none.a-color-base.a-text-normal").first().waitFor();
  await page.locator(".a-size-base-plus.a-spacing-none.a-color-base.a-text-normal").first().click();

});
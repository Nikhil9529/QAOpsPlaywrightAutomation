import { test, expect } from '@playwright/test';

test.describe.configure({ mode: 'parallel' });
test("Popup Validations", async ({page}) =>
{
    // Test implementation for popup validations
    await page.goto("https://rahulshettyacademy.com/AutomationPractice/");
    //await page.goto("https://google.com");
    //await page.goBack();
    //await page.goForward();

    await expect(page.locator("#displayed-text")).toBeVisible();
    await page.locator("#displayed-text").waitFor();
    await page.locator("#hide-textbox").click();
    await expect(page.locator("#displayed-text")).toBeHidden();
    await page.on('dialog', async dialog => dialog.accept());
    await page.locator("#confirmbtn").click();
    await page.locator("#mousehover").hover();
    const framesPage = page.frameLocator("#courses-iframe");
    await framesPage.locator("li a[href*='lifetime-access']:visible").click();
    const frameText = await framesPage.locator(".text h2").textContent();
    console.log(frameText.split(" ")[1]);
   
})

test("Screens & Visual comparision",async({page})=>
{
    await page.goto("https://rahulshettyacademy.com/AutomationPractice/");

    await expect(page.locator("#displayed-text")).toBeVisible();
    await page.locator("#displayed-text").screenshot({path: 'PartialScreenshot.png'});
    await page.locator("#displayed-text").waitFor();
    await page.locator("#hide-textbox").click();
    await page.screenshot({path: 'screenshot.png'});
    await expect(page.locator("#displayed-text")).toBeHidden();
});

test("visual", async({page})=>
{
    await page.goto("https://google.com");
    expect(await page.screenshot()).toMatchSnapshot('landing.png');
})